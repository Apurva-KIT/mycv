import {
  Compiler,
  Component,
  ComponentFactory,
  ComponentRef,
  Injector,
  Input,
  ModuleWithComponentFactories,
  NgModule,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewContainerRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PdfViewerModule } from 'ng2-pdf-viewer';

// here we have all custom components allowed for dynamic render
// import { DynamicComponentsModule } from '../dynamic-components/dynamic-components.module';


@Component({
  selector: 'html-renderer',
  templateUrl: './html-renderer.component.html',
  styleUrls: ['./html-renderer.component.scss']
})
export class HtmlRendererComponent implements OnInit, OnChanges, OnDestroy {
  @Input() content: string | undefined // '<h1>Title...</h1> <some-component></some-component>
  cmpRef: ComponentRef<any> | undefined;

  constructor(private vcRef: ViewContainerRef, private compiler: Compiler) {}

  ngOnInit(): void {
    console.log('content:::', this.content);
  }

  ngOnDestroy() {
    if (this.cmpRef) {
      this.cmpRef.destroy();
    }
  }

  ngOnChanges() {
    debugger;
    this.createComponentOnChanges();
  }


  public createComponentOnChanges(content?:string) {
    debugger;
    const html = this.content? this.content : content;
    // if (!html) {
    //   return;
    // }

    if (this.cmpRef) {
      this.cmpRef.destroy();
    }

    const compMetadata = new Component({
      template: this.content
      // todo: check styles and other options
    });

    createComponentFactory(this.compiler, compMetadata).then(factory => {
      const injector = Injector.create({
        providers: [],
        parent: this.vcRef.injector
      });

      if(factory !== undefined)
        this.cmpRef = this.vcRef.createComponent(factory, 0, injector, []);
    });
  }

}



export async function createComponentFactory(
  compiler: Compiler,
  metadata: Component
): Promise<ComponentFactory<any> | undefined> {
  const cmpClass = class DynamicComponent {};
  const decoratedCmp = Component(metadata)(cmpClass);

  const moduleClass = class RuntimeComponentModule {
  };
  const DynamicHtmlModule = NgModule({ imports: [
    CommonModule,
      RouterModule,
      PdfViewerModule

  ], declarations: [decoratedCmp] })(moduleClass);
  
  // const module: ModuleWithComponentFactories<any> = compiler.compileModuleAndAllComponentsSync(decoratedNgModule);
  // IMPORT ALL MODULES HERE!!!
  // @NgModule({
  //   imports: [
  //     CommonModule,
  //     RouterModule,
  //     PdfViewerModule
  //     // DynamicComponentsModule
  //     /* All other modules including components that can be use with renderer */
  //   ],
  //   declarations: [decoratedCmp]
  // })
  // class DynamicHtmlModule {}

  const moduleWithComponentFactory = await compiler.compileModuleAndAllComponentsAsync(
    DynamicHtmlModule
  );
  return moduleWithComponentFactory.componentFactories.find(
    x => x.componentType === decoratedCmp
  );
}

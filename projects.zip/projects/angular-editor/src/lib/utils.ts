export function isDefined(value: any) {
  return value !== undefined && value !== null;
}

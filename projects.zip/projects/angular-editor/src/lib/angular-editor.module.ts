import {NgModule} from '@angular/core';
import {AngularEditorComponent} from './angular-editor.component';
import {AngularEditorToolbarComponent} from './angular-editor-toolbar.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import { AeSelectComponent } from './ae-select/ae-select.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { HtmlRendererComponent } from '../../../angular-editor-app/src/app/html-renderer/html-renderer.component';

@NgModule({
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule,PdfViewerModule
  ],
  declarations: [AngularEditorComponent, AngularEditorToolbarComponent, AeSelectComponent,HtmlRendererComponent],
  exports: [AngularEditorComponent, AngularEditorToolbarComponent,HtmlRendererComponent]
})
export class AngularEditorModule {
}
